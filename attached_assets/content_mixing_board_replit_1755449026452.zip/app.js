// Lightweight, framework-free Mixing Board
(function () {
  // --- Seeded example content (based on our SkyClaim work) ---
  const defaultSeedName = "Hurricane Eric Pre‑Storm";
  const seedsDefault = {
    [defaultSeedName]: {
      categories: {
        headline: [
          { id: "H1", label: "Urgent / FOMO", text: "Hurricane Eric Is Coming — Don’t Wait Until It’s Too Late" },
          { id: "H2", label: "Calm / Relief", text: "One Less Thing to Worry About When the Storm Hits" },
          { id: "H3", label: "Priority / Exclusive", text: "Be First in Line for Roof Repairs After the Storm" }
        ],
        subhead: [
          { id: "S1", label: "Urgent setup", text: "Lock in your free inspection today before the storm rush begins." },
          { id: "S2", label: "Relief / Preparedness", text: "We’ll handle your roof inspection and insurance prep now — so you can stay calm later." },
          { id: "S3", label: "Top of list", text: "Submit your info now and secure your place at the top of the list." }
        ],
        body: [
          { id: "B1", label: "Short Pitch (30–60s)", text:
`Stay Ahead of Hurricane Eric — Free Pre‑Storm Roof Inspection.
Don’t wait until the chaos hits. Contact us now, share your policy info, and secure a complimentary inspection. If your roof needs coverage, we’ll help before the storm — and if not, you’ll be first in line for fast repairs and replacement after. One less thing to worry about.` },
          { id: "B2", label: "Full Landing Page", text:
`Be Ready Before the Storm — Free Pre‑Storm Roof Inspection

When a hurricane hits, everything gets overwhelming fast. Insurance claims pile up, contractors get booked, and repairs can drag on for months. But with SkyClaim, you can stay ahead.

By contacting us now and providing your policy information, you get:
• Complimentary Pre‑Storm Inspection — We’ll check your roof at no cost to you.
• Early Coverage Opportunity — If we find damage now, you may be able to get it covered before the storm.
• Priority Response After the Storm — Even if your roof is fine today, you’ll already be at the top of our list once the storm passes.

This means when the chaos starts, you don’t have to scramble. SkyClaim already has your information, inspection, and game plan in hand. Focus on your family and safety knowing your roof is taken care of.

Don’t wait until it’s too late. Secure your free inspection today and check this off your list before the storm arrives.` },
          { id: "B3", label: "Anxiety‑Relief Landing", text:
`Don’t Get Stuck in the Chaos — Secure Your Roof Before the Storm

When a hurricane hits, the phones blow up. Insurance adjusters get overwhelmed. Roofers are booked out for weeks. Everyone is scrambling at the same time.

But not you.

With SkyClaim, you can skip the panic. Right now, before the storm arrives, we’ll:
• Do a complimentary pre‑storm inspection of your roof
• File your policy information ahead of time, so you’re ready for coverage
• Lock in your place at the top of the list for repairs or replacement after the storm

While everyone else is panicking, you’ll be calm. Your inspection is done. Your policy is in. Your spot is saved.

Check this off your list today — before the storm, before the chaos, before the stress.` }
        ],
        cta: [
          { id: "C1", label: "Primary CTA", text: "Claim Your Free Pre‑Storm Inspection" },
          { id: "C2", label: "Priority CTA", text: "Reserve Top‑of‑List Status" },
          { id: "C3", label: "Relief CTA", text: "Get Peace of Mind Now" }
        ]
      },
      votes: {} // comboId -> { up, down, stars:[], agentScore }
    }
  };

  // --- Persistence helpers (localStorage) ---
  const LS_KEY = "mixing_board_seeds_v1";
  function loadSeeds() {
    try {
      const raw = localStorage.getItem(LS_KEY);
      if (!raw) return JSON.parse(JSON.stringify(seedsDefault));
      return JSON.parse(raw);
    } catch {
      return JSON.parse(JSON.stringify(seedsDefault));
    }
  }
  function saveSeeds(seeds) {
    localStorage.setItem(LS_KEY, JSON.stringify(seeds));
  }

  // --- State ---
  let seeds = loadSeeds();
  let currentSeedName = defaultSeedName;
  let currentSelection = { headline: null, subhead: null, body: null, cta: null };

  // --- DOM refs ---
  const seedInput = document.getElementById("seedInput");
  const categoriesContainer = document.getElementById("categoriesContainer");
  const previewHeadline = document.getElementById("previewHeadline");
  const previewSubhead = document.getElementById("previewSubhead");
  const previewCopy = document.getElementById("previewCopy");
  const previewCTA = document.getElementById("previewCTA");
  const currentComboIdEl = document.getElementById("currentComboId");
  const leaderTable = document.getElementById("leaderTable").querySelector("tbody");

  // --- Utilities ---
  function ensureSeed(name) {
    if (!seeds[name]) {
      seeds[name] = JSON.parse(JSON.stringify(seedsDefault[defaultSeedName]));
      seeds[name].votes = {};
      saveSeeds(seeds);
    }
  }

  function getSeed() {
    ensureSeed(currentSeedName);
    return seeds[currentSeedName];
  }

  function comboId(sel) {
    if (!sel.headline || !sel.subhead || !sel.body || !sel.cta) return "—";
    return [sel.headline.id, sel.subhead.id, sel.body.id, sel.cta.id].join("|");
  }

  function renderCategories() {
    const { categories } = getSeed();
    categoriesContainer.innerHTML = "";
    Object.entries(categories).forEach(([catKey, items]) => {
      const catEl = document.createElement("div");
      catEl.className = "category";

      const h = document.createElement("h3");
      h.textContent = catKey[0].toUpperCase() + catKey.slice(1);
      catEl.appendChild(h);

      const row = document.createElement("div");
      row.className = "options-row";
      items.forEach(item => {
        const card = document.createElement("div");
        card.className = "card";
        card.tabIndex = 0;
        card.innerHTML = `
          <div class="text">${escapeHtml(item.text)}</div>
          <div class="meta">ID: ${item.id}${item.label ? " • " + escapeHtml(item.label) : ""}</div>
        `;
        card.addEventListener("click", () => {
          currentSelection[catKey] = item;
          updatePreview();
          refreshSelectedCards(catKey, item.id);
        });
        row.appendChild(card);
      });
      catEl.appendChild(row);
      categoriesContainer.appendChild(catEl);
    });
    refreshSelectedCards();
  }

  function refreshSelectedCards(targetKey, selectedId) {
    const { categories } = getSeed();
    Object.keys(categories).forEach(catKey => {
      const catEl = categoriesContainer.querySelectorAll(".category")[
        Object.keys(categories).indexOf(catKey)
      ];
      const cards = catEl.querySelectorAll(".card");
      cards.forEach((card, idx) => {
        const item = categories[catKey][idx];
        const isSelected = currentSelection[catKey]?.id === item.id;
        card.classList.toggle("selected", isSelected);
      });
    });
    currentComboIdEl.textContent = comboId(currentSelection);
  }

  function updatePreview() {
    previewHeadline.textContent = currentSelection.headline?.text || "Select a headline…";
    previewSubhead.textContent = currentSelection.subhead?.text || "";
    previewCopy.innerHTML = currentSelection.body
      ? markdownToHtml(currentSelection.body.text)
      : "";
    if (currentSelection.cta) {
      previewCTA.textContent = currentSelection.cta.text;
      previewCTA.disabled = false;
    } else {
      previewCTA.textContent = "Choose a CTA";
      previewCTA.disabled = true;
    }
    currentComboIdEl.textContent = comboId(currentSelection);
  }

  function markdownToHtml(md) {
    // super-minimal formatter: bullets + paragraph breaks
    const escaped = escapeHtml(md);
    const withBullets = escaped.replace(/^• (.*)$/gm, "<li>$1</li>");
    const withLists = withBullets.replace(/(<li>[\s\S]*?<\/li>)/g, "<ul>$1</ul>");
    return withLists.replace(/\n\n+/g, "</p><p>").replace(/^/, "<p>").replace(/$/, "</p>");
  }

  function escapeHtml(str) {
    return String(str)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");
  }

  // --- Voting & Leaderboard ---
  function getVotes() {
    const seed = getSeed();
    return seed.votes || (seed.votes = {});
  }

  function recordVote(kind, starsVal=null, combo=null) {
    const sel = combo || currentSelection;
    const id = comboId(sel);
    if (id === "—") return;
    const votes = getVotes();
    if (!votes[id]) votes[id] = { up: 0, down: 0, stars: [], agentScore: 0 };
    if (kind === "up") votes[id].up += 1;
    if (kind === "down") votes[id].down += 1;
    if (kind === "stars" && starsVal) votes[id].stars.push(starsVal);
    saveSeeds(seeds);
    renderLeaderboard();
  }

  function avgStars(stars) {
    if (!stars || stars.length === 0) return 0;
    return stars.reduce((a,b) => a + b, 0) / stars.length;
    }

  function scoreRow(v) {
    // Simple composite: (up - down) + avgStars*0.8 + agentScore*2
    const base = (v.up - v.down);
    return base + avgStars(v.stars)*0.8 + (v.agentScore || 0)*2;
  }

  function renderLeaderboard() {
    const { categories } = getSeed();
    const votes = getVotes();
    const rows = Object.entries(votes).map(([id, v]) => {
      const [hId, sId, bId, cId] = id.split("|");
      const h = categories.headline.find(i => i.id === hId);
      const s = categories.subhead.find(i => i.id === sId);
      const b = categories.body.find(i => i.id === bId);
      const c = categories.cta.find(i => i.id === cId);
      return { id, h, s, b, c, v, score: scoreRow(v) };
    }).sort((a, b) => b.score - a.score);

    leaderTable.innerHTML = "";
    rows.forEach((row, idx) => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${idx+1}</td>
        <td>${row.id}</td>
        <td>${escapeHtml(row.h?.text || "")}</td>
        <td>${escapeHtml(row.s?.text || "")}</td>
        <td>${escapeHtml(row.b?.label || "")}</td>
        <td>${escapeHtml(row.c?.text || "")}</td>
        <td>${row.score.toFixed(2)}<br/>
            <span class="mini">👍 ${row.v.up} • 👎 ${row.v.down} • ★ ${avgStars(row.v.stars).toFixed(1)} • 🤖 ${row.v.agentScore?.toFixed(2) || "0.00"}</span>
        </td>
        <td><button class="btn btn-secondary" data-load="${row.id}">Load</button></td>
      `;
      leaderTable.appendChild(tr);
    });

    leaderTable.querySelectorAll("[data-load]").forEach(btn => {
      btn.addEventListener("click", () => {
        const id = btn.getAttribute("data-load");
        loadComboById(id);
      });
    });
  }

  function loadComboById(id) {
    const { categories } = getSeed();
    const [hId, sId, bId, cId] = id.split("|");
    currentSelection.headline = categories.headline.find(i => i.id === hId) || null;
    currentSelection.subhead = categories.subhead.find(i => i.id === sId) || null;
    currentSelection.body = categories.body.find(i => i.id === bId) || null;
    currentSelection.cta = categories.cta.find(i => i.id === cId) || null;
    updatePreview();
    refreshSelectedCards();
  }

  // --- Agent scoring (toy heuristic you can swap out) ---
  function agentScoreCombo(sel) {
    const H = sel.headline?.text || "";
    const S = sel.subhead?.text || "";
    const B = sel.body?.text || "";
    const C = sel.cta?.text || "";

    // Token-ish length penalties
    const lenPenalty = Math.max(0, (H.length - 80) / 100);

    // Keyword boosts
    const kws = ["Hurricane", "Free", "Pre‑Storm", "Top", "Priority", "Don’t Wait"];
    const kwBoost = [H,S,B,C].join(" ").split(/\s+/).reduce((acc, w) => {
      return acc + (kws.includes(w.replace(/[^\w‑’']/g,"")) ? 0.4 : 0);
    }, 0);

    // CTA strength (shorter often better)
    const ctaBoost = Math.max(0, 1.2 - (C.length / 40));

    // Body readability proxy (ideal 120–700 chars)
    const bl = B.length;
    const bodyFit = bl < 120 ? 0.2 : bl > 900 ? 0.2 : 1.0;

    let score = 1.0 + kwBoost + ctaBoost + bodyFit - lenPenalty;
    // Normalize a bit
    return Math.max(0, Math.min(score / 3.0, 1.0));
  }

  function runAgentScoringForAllCombos() {
    const combos = generateAllCombos();
    combos.forEach(sel => {
      const id = comboId(sel);
      const score = agentScoreCombo(sel);
      const votes = getVotes();
      if (!votes[id]) votes[id] = { up: 0, down: 0, stars: [], agentScore: 0 };
      votes[id].agentScore = score;
    });
    saveSeeds(seeds);
    renderLeaderboard();
  }

  // --- Combo generation ---
  function generateAllCombos() {
    const { categories } = getSeed();
    const combos = [];
    categories.headline.forEach(h => {
      categories.subhead.forEach(s => {
        categories.body.forEach(b => {
          categories.cta.forEach(c => {
            combos.push({ headline: h, subhead: s, body: b, cta: c });
          });
        });
      });
    });
    return combos;
  }

  // --- Event wiring ---
  document.getElementById("randomizeBtn").addEventListener("click", () => {
    const { categories } = getSeed();
    currentSelection.headline = randOf(categories.headline);
    currentSelection.subhead = randOf(categories.subhead);
    currentSelection.body = randOf(categories.body);
    currentSelection.cta = randOf(categories.cta);
    updatePreview();
    refreshSelectedCards();
  });

  document.getElementById("saveComboBtn").addEventListener("click", () => {
    const id = comboId(currentSelection);
    if (id === "—") return;
    const votes = getVotes();
    if (!votes[id]) votes[id] = { up: 0, down: 0, stars: [], agentScore: agentScoreCombo(currentSelection) };
    saveSeeds(seeds);
    renderLeaderboard();
  });

  document.getElementById("upVote").addEventListener("click", () => recordVote("up"));
  document.getElementById("downVote").addEventListener("click", () => recordVote("down"));

  document.getElementById("starRow").querySelectorAll("button").forEach(btn => {
    btn.addEventListener("click", () => {
      const val = parseInt(btn.dataset.star, 10);
      document.querySelectorAll(".stars button").forEach(b => b.classList.remove("active"));
      for (let i=0;i<val;i++) document.querySelectorAll(".stars button")[i].classList.add("active");
      recordVote("stars", val);
    });
  });

  document.getElementById("agentScoreBtn").addEventListener("click", runAgentScoringForAllCombos);

  document.getElementById("generateAllBtn").addEventListener("click", () => {
    const combos = generateAllCombos();
    combos.forEach(sel => {
      const id = comboId(sel);
      const votes = getVotes();
      if (!votes[id]) votes[id] = { up: 0, down: 0, stars: [], agentScore: agentScoreCombo(sel) };
    });
    saveSeeds(seeds);
    renderLeaderboard();
  });

  document.getElementById("clearVotesBtn").addEventListener("click", () => {
    if (!confirm("Clear votes for this seed?")) return;
    const seed = getSeed();
    seed.votes = {};
    saveSeeds(seeds);
    renderLeaderboard();
  });

  // Seed controls
  document.getElementById("loadSeedBtn").addEventListener("click", () => {
    const name = (seedInput.value || "").trim();
    if (!name) return;
    currentSeedName = name;
    ensureSeed(currentSeedName);
    currentSelection = { headline: null, subhead: null, body: null, cta: null };
    renderCategories();
    updatePreview();
    renderLeaderboard();
  });

  document.getElementById("newSeedBtn").addEventListener("click", () => {
    const base = "New Campaign ";
    let i = 1;
    while (seeds[base + i]) i++;
    const name = base + i;
    seeds[name] = JSON.parse(JSON.stringify(seedsDefault[defaultSeedName]));
    seeds[name].votes = {};
    saveSeeds(seeds);
    seedInput.value = name;
    currentSeedName = name;
    renderCategories();
    updatePreview();
    renderLeaderboard();
  });

  document.getElementById("saveSeedBtn").addEventListener("click", () => {
    saveSeeds(seeds);
    flash("Saved.");
  });

  document.getElementById("exportBtn").addEventListener("click", () => {
    const dataStr = JSON.stringify(seeds, null, 2);
    const blob = new Blob([dataStr], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "mixing_board_seeds.json";
    a.click();
    URL.revokeObjectURL(url);
  });

  document.getElementById("importFile").addEventListener("change", (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const obj = JSON.parse(reader.result);
        seeds = obj;
        saveSeeds(seeds);
        flash("Import successful.");
        renderCategories();
        updatePreview();
        renderLeaderboard();
      } catch (err) {
        alert("Invalid JSON file.");
      }
    };
    reader.readAsText(file);
  });

  function randOf(arr) { return arr[Math.floor(Math.random()*arr.length)]; }

  function flash(msg) {
    const el = document.createElement("div");
    el.textContent = msg;
    el.style.position = "fixed";
    el.style.bottom = "16px";
    el.style.right = "16px";
    el.style.padding = "10px 12px";
    el.style.background = "#1c2440";
    el.style.border = "1px solid #2b3a67";
    el.style.borderRadius = "8px";
    el.style.zIndex = "9999";
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 1600);
  }

  // Init
  seedInput.value = currentSeedName;
  renderCategories();
  updatePreview();
  renderLeaderboard();
})();