# ElevenLabs Agent Provisioner (Replit-Ready)

This tiny project gives you two things:
1) A **webhook server** your ElevenLabs agent can call to perform actions.
2) A **provisioner CLI** that **automates** ElevenLabs setup: creates a secret, creates a webhook tool, and attaches that tool to your Agent (by ID).

No prior coding needed — just paste commands and fill your IDs/URLs.

---

## Quick Start (5–10 minutes)

1. **Fork or Import** this repo into Replit.
2. Add secrets (Replit → Tools → Secrets):
   - `ELEVENLABS_API_KEY`: your ElevenLabs API key (auth header is `xi-api-key`)
   - `ELEVEN_SHARED_TOKEN`: any long random string (used as a shared bearer token)
   - *(optional)* `CALCOM_API_KEY` if you plan to use the Cal.com preset
3. Install & run:
   ```bash
   npm install
   npm start
   ```
   Replit will show a **public URL** like `https://<your-repl>.<user>.repl.co`.  
   Your **webhook URL** is that + `/voice-action`.
4. **Smoke test** (before ElevenLabs):
   ```bash
   export ELEVEN_SHARED_TOKEN=<same token you put in Secrets>
   bash scripts/post_test.sh https://<your-repl>.<user>.repl.co voice-action create_note "Test note" you@example.com
   ```
   You should see `{ "ok": true, "message": "Note created." }` and logs in the Replit console.

---

## One-Command Provisioning (adds a Tool to your Agent)

Run the provisioner to program ElevenLabs for you:

```bash
node provision.js     --agent <YOUR_AGENT_ID>     --url https://<your-repl>.<user>.repl.co/voice-action     --tool run_action     --secret-name shared_token     --secret-value "$ELEVEN_SHARED_TOKEN"
```

What it does:
- creates a **workspace secret** in ElevenLabs (name `shared_token`, value `Bearer <your token>`),
- creates a **webhook Tool** named `run_action` that POSTs JSON to your `/voice-action` endpoint, with the `Authorization` header pulling from that secret,
- **attaches** the tool to your agent by ID.

> If the API paths change (ElevenLabs is iterating fast), the script tries two common paths. If both fail, it prints the error so you can adjust.

---

## Teach your Agent when to call the tool

In your Agent’s **System Prompt**, add something like:

> If the user asks you to *do* something, call `run_action`.  
> Use `action` as a short verb (e.g., `create_note`, `send_email`) and put details in `details`.  
> After the tool returns, summarize the result back to the user.

Try: “Make a note that Lauren called about the roof estimate and email me the details.”  
You should see the call hit your Replit logs.

---

## Cal.com Preset (optional)

This creates two tools (`get_available_slots`, `book_meeting`) and attaches them to your agent:

```bash
node provision-calcom.js --agent <YOUR_AGENT_ID> --calkey "$CALCOM_API_KEY"
```

You’ll still want to **guide** the agent in your prompt:
- Ask for purpose, date/time, duration, attendee email.
- Call `get_available_slots` first.
- If available, call `book_meeting` with the chosen time.

---

## Extend your `/voice-action`

Open `server.js` and add new `case` branches:
```js
case 'update_crm':
  // call your CRM API here
  message = 'CRM updated.';
  break;
```

Keep using the **same tool** (`run_action`) but send different `action` names from the agent.

---

## FAQ

**Where do webhook URLs come from?**  
From your running server. Replit gives you a public base URL; you choose the path (e.g., `/voice-action`).

**Which goes first?**  
Always build & test your webhook **first**, then run the provisioner and paste the **working URL**.

**Why a shared token?**  
The agent includes `Authorization: Bearer <token>`; your server checks it to block random callers.

**n8n optional?**  
Yes. This project is Replit-only. You can add n8n later if you want visual flows and drag-and-drop integrations.

---

## Troubleshooting

- **401 Unauthorized** → Make sure `ELEVEN_SHARED_TOKEN` matches on both sides.  
- **Agent doesn’t call tool** → Strengthen the system prompt; be explicit about when to call `run_action`.  
- **Provisioner 404/400** → The API path/schema may have changed; open `provision.js` and tweak endpoints. The script already tries two common base paths.  
- **Empty JSON** → Ensure `app.use(express.json())` is present.

---

## Security Notes

- Always use HTTPS (Replit is HTTPS by default).  
- Store secrets in Replit Secrets and ElevenLabs Secrets (never hard-code).  
- Validate and sanitize user input in actions that touch your database.

---

## License

MIT
