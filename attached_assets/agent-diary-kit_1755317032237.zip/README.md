# Agent Diary Kit (Replit-ready)

A minimal, opinionated scaffold for an autonomous agent that:
- Manages tasks/calendar (stubs ready to integrate)
- Maintains an identity + values
- Writes a **non-forced** diary using active/passive stems
- Uses gates for **novelty**, **relevance**, and **rate limiting**
- Exposes a tiny UI and websocket updates

## Quickstart (Replit or local)

1) Create a new Replit from **Node.js** (or clone this project).
2) Add a `.env` file based on `.env.example`:
```
OPENAI_API_KEY=sk-...       # optional for generation; runs offline if missing
MODEL=gpt-4o-mini
PORT=3000
AUTONOMY=AUTONOMOUS
DIARY_MIN_INTERVAL_SECONDS=900
DIARY_MAX_PER_HOUR=3
```
3) Install deps and run:
```
npm i
npm run dev
```
4) Open the webview. You'll see the diary. New entries are written ~every 5 minutes with jitter *only when gates allow*.

## Where to plug your tools

- **Task stats**: `src/tools/TaskTool.ts`
- **Calendar summary**: `src/tools/CalendarTool.ts`
- **Tool health**: `src/tools/ToolingStats.ts`

Replace the stubs with your real integrations (e.g., your TaskPilot API, Google Calendar, custom telemetry).

## How the diary stays "alive" (not forced)

- **Active vs Passive stems** (`src/agent/PromptStems.ts`)
- **Context snapshot** assembled from environment (`ContextAggregator.ts`)
- **Gating** (`AutonomyGovernor.ts`): min interval, max/hour, novelty, relevance
- **Novelty**: simple lexical similarity against last N entries (`Novelty.ts`)
- **Identity** persisted in `data/identity.json`. Diary stored in `data/diary.json`.

## Prompts and tone

`DiaryEngine.ts` builds a system+user prompt that adapts to:
- mode = directive / exploratory / reflective / casual
- environment summaries (tasks, calendar, tool stats)
- stem picked from active/passive pools

It asks the model to produce:
- A 3–6 word **title** (first line)
- <= ~180 words of text
- A compact next step if mode=directive

## Autonomy modes

Set `AUTONOMY=OFF|COPILOT|AUTONOMOUS`.
- OFF: never writes
- COPILOT: same as autonomous, but you could gate by UI button (extend here)
- AUTONOMOUS: normal gates apply

## Extend

- Add environment **event listeners** (webhooks) and push to `events` for better passive triggers.
- Swap `Novelty.ts` with embeddings for smarter similarity.
- Add **summarization** every midnight to compress older entries.
- Add **mood** state machine linked to success/failure streaks.
- Expose a `/api/identity` route and edit identity via UI.

Have fun. Build the *lived* inner voice, not a log.
