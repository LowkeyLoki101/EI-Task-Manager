export async function getTaskStats(): Promise<{ open: number; overdue: number; changed: number }> {
  // TODO: integrate real task API (e.g., your TaskPilot)
  return {
    open: Math.floor(Math.random()*25 + 5),
    overdue: Math.floor(Math.random()*7),
    changed: Math.floor(Math.random()*10)
  };
}
