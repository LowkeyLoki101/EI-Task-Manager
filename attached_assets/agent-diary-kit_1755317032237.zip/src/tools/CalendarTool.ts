export async function getCalendarSummary(): Promise<{ meetingsToday: number; upcoming: number }> {
  // TODO: integrate real calendar API
  return { meetingsToday: Math.floor(Math.random()*4), upcoming: Math.floor(Math.random()*6) };
}
