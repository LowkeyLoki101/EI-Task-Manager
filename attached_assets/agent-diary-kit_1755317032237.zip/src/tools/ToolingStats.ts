export async function getToolStats(): Promise<{ successes: number; errors: number }> {
  // TODO: integrate per-tool telemetry
  return {
    successes: Math.floor(Math.random()*10 + 5),
    errors: Math.floor(Math.random()*3)
  };
}
