import 'dotenv/config';
import express from 'express';
import { WebSocketServer } from 'ws';
import { toContextSnapshot, RawEnvironment } from './agent/ContextAggregator.ts';
import { getCalendarSummary } from './tools/CalendarTool.ts';
import { getTaskStats } from './tools/TaskTool.ts';
import { getToolStats } from './tools/ToolingStats.ts';
import { maybeWriteDiary } from './agent/DiaryEngine.ts';
import { loadDiary } from './agent/MemoryStore.ts';
import { shouldWriteDiary, GateConfig } from './agent/AutonomyGovernor.ts';
import { AutonomyMode } from './types.ts';

const app = express();
app.use(express.json());

// simple REST to read diary
app.get('/api/diary', (_req, res) => {
  res.json(loadDiary());
});

// WebSocket to broadcast diary updates
const server = app.listen(process.env.PORT || 3000, () => {
  console.log('Server listening on', process.env.PORT || 3000);
});
const wss = new WebSocketServer({ server });

function broadcast(obj: any) {
  const data = JSON.stringify(obj);
  for (const client of wss.clients) {
    if (client.readyState === 1) client.send(data);
  }
}

// Agent loop
const autonomy: AutonomyMode = (process.env.AUTONOMY as AutonomyMode) || 'AUTONOMOUS';
const minInterval = Number(process.env.DIARY_MIN_INTERVAL_SECONDS || 900);
const maxPerHour = Number(process.env.DIARY_MAX_PER_HOUR || 3);

const gates: GateConfig = {
  minIntervalSeconds: minInterval,
  maxPerHour: maxPerHour,
  noveltyThreshold: 0.35,
  relevanceThreshold: 0.2
};

async function tick() {
  // Aggregate environment (replace with real data sources)
  const envRaw: RawEnvironment = {
    events: [],
    tasks: await getTaskStats(),
    calendar: await getCalendarSummary(),
    tools: await getToolStats(),
    autonomy
  };

  const ctx = toContextSnapshot(envRaw);

  // Decide active vs passive
  const envSignal = ctx.toolsUsageSummary.includes('err') || ctx.tasksSummary.includes('overdue');
  const kind = envSignal ? 'passive' as const : 'active' as const;

  // Rough relevance & novelty prediction (pre-gen)
  const relevanceGuess = envSignal ? 0.6 : 0.3;
  const noveltyGuess = Math.random() * 0.6 + 0.2;

  const gate = shouldWriteDiary(ctx.autonomy, new Date(), relevanceGuess, noveltyGuess, gates);
  if (gate.allow) {
    const out = await maybeWriteDiary(ctx, kind);
    if (out.wrote && out.entry) {
      broadcast({ type: 'diary:new', entry: out.entry });
      console.log('Diary:', out.entry.title);
    }
  } else {
    // console.log('Skip diary:', gate.reason);
  }
}

// Run every ~5 minutes with jitter
function scheduleNext() {
  const base = 5 * 60 * 1000;
  const jitter = Math.floor(Math.random() * 60_000);
  setTimeout(async () => {
    try { await tick(); } catch (e) { console.error(e); }
    scheduleNext();
  }, base + jitter);
}

scheduleNext();

// minimal UI
app.get('/', (_req, res) => {
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.end(`<!doctype html>
<html><head><meta charset="utf-8"><title>Agent Diary</title>
<style>
body{font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif;margin:2rem;line-height:1.4}
.entry{border:1px solid #ccc;border-radius:8px;padding:12px;margin:12px 0}
.meta{font-size:12px;color:#666}
.title{font-weight:600;margin-bottom:6px}
</style>
</head><body>
<h1>Agent Diary</h1>
<div id="list"></div>
<script>
async function load() {
  const res = await fetch('/api/diary');
  const entries = await res.json();
  render(entries);
}
function render(entries){
  const root = document.getElementById('list');
  root.innerHTML = entries.slice().reverse().map(e=>\`
    <div class="entry">
      <div class="title">\${e.title}</div>
      <div class="meta">\${new Date(e.timestamp).toLocaleString()} • mode: \${e.mode} • \${e.activeOrPassive}</div>
      <pre style="white-space:pre-wrap;margin:6px 0">\${e.text}</pre>
      <div class="meta">hooks: \${(e.hooks||[]).join(', ')} • novelty: \${e.score?.novelty?.toFixed(2)} • relevance: \${e.score?.relevance?.toFixed(2)}</div>
    </div>
  \`).join('');
}
load();
const ws = new WebSocket((location.protocol==='https:'?'wss':'ws')+'://'+location.host);
ws.onmessage = (ev)=>{
  const msg = JSON.parse(ev.data);
  if (msg.type==='diary:new') load();
};
</script>
</body></html>`);
});
