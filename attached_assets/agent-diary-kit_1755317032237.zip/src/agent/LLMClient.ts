import 'dotenv/config';

export interface GenOptions {
  system: string;
  prompt: string;
  model?: string;
  temperature?: number;
  maxTokens?: number;
}

export async function generateText(opts: GenOptions): Promise<string> {
  const key = process.env.OPENAI_API_KEY;
  if (!key) {
    // Offline fallback to keep dev flow working
    return `[LLM OFFLINE] ${opts.prompt}\n(Provide OPENAI_API_KEY to enable generation.)`;
  }
  const model = opts.model || process.env.MODEL || 'gpt-4o-mini';
  const body = {
    model,
    messages: [
      { role: 'system', content: opts.system },
      { role: 'user', content: opts.prompt }
    ],
    temperature: opts.temperature ?? 0.7
  };

  const res = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${key}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(body)
  });
  if (!res.ok) {
    const txt = await res.text();
    throw new Error(`OpenAI API error: ${res.status} ${txt}`);
  }
  const json = await res.json();
  return json.choices?.[0]?.message?.content ?? '';
}
