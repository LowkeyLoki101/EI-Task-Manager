import { AgentContextSnapshot, AutonomyMode, DiaryEntry, EnvironmentEvent, IdentityState } from '../types.ts';
import { loadDiary, loadIdentity } from './MemoryStore.ts';

export interface RawEnvironment {
  events: EnvironmentEvent[];
  tasks: { open: number; overdue: number; changed: number };
  calendar: { meetingsToday: number; upcoming: number };
  tools: { successes: number; errors: number };
  autonomy: AutonomyMode;
}

export function summarizeTasks(t: RawEnvironment['tasks']): string {
  return `open:${t.open} overdue:${t.overdue} changed:${t.changed}`;
}

export function summarizeCalendar(c: RawEnvironment['calendar']): string {
  return `meetingsToday:${c.meetingsToday} upcoming:${c.upcoming}`;
}

export function summarizeTools(t: RawEnvironment['tools']): string {
  return `ok:${t.successes} err:${t.errors}`;
}

export function toContextSnapshot(raw: RawEnvironment): AgentContextSnapshot {
  const id: IdentityState = loadIdentity();
  const lastDiary: DiaryEntry[] = loadDiary().slice(-5);
  const nowISO = new Date().toISOString();
  const mood = deriveMood(raw);
  const focus = deriveFocus(raw);

  return {
    nowISO,
    autonomy: raw.autonomy,
    mood,
    focus,
    recentEvents: raw.events.slice(-10),
    tasksSummary: summarizeTasks(raw.tasks),
    calendarSummary: summarizeCalendar(raw.calendar),
    toolUsageSummary: summarizeTools(raw.tools),
    identity: id,
    lastDiaryEntries: lastDiary
  };
}

function deriveMood(raw: RawEnvironment): string {
  if (raw.tools.errors > 2) return 'cautious';
  if (raw.tasks.overdue > 5) return 'urgent';
  if (raw.calendar.meetingsToday > 4) return 'compressed';
  return 'steady';
}

function deriveFocus(raw: RawEnvironment): string {
  if (raw.tasks.overdue > 0) return 'clear overdue';
  if (raw.tools.errors > 0) return 'stabilize tools';
  return 'advance priorities';
}
