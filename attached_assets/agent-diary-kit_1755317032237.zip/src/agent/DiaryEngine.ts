import { v4 as uuid } from 'uuid';
import { AgentContextSnapshot, DiaryEntry } from '../types.ts';
import { ACTIVE_STEMS, PASSIVE_STEMS, TITLES } from './PromptStems.ts';
import { noveltyScore, hooksFrom } from './Novelty.ts';
import { appendDiary } from './MemoryStore.ts';
import { generateText } from './LLMClient.ts';

export interface DiaryConfig {
  maxChars?: number;
}

function pick<T>(arr: readonly T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

function buildPrompt(ctx: AgentContextSnapshot, activeOrPassive: 'active'|'passive'): { mode: DiaryEntry['mode']; prompt: string } {
  // Choose a mode based on context
  const mode: DiaryEntry['mode'] = ctx.focus.includes('overdue') ? 'directive'
    : ctx.mood === 'cautious' ? 'reflective'
    : Math.random() < 0.33 ? 'exploratory'
    : Math.random() < 0.5 ? 'casual'
    : 'directive';

  const stems = activeOrPassive === 'active' ? ACTIVE_STEMS : PASSIVE_STEMS;
  const stem = pick(stems[mode]);

  const sys = `You are ${ctx.identity.name}, an autonomous operator that manages tasks and calendar, uses tools, and writes a short, meaningful diary. Tone depends on mode.
- directive: operational, concise, clear next steps
- exploratory: curious, pattern-finding, hypothesis-driven
- reflective: narrative, honest, meaning-making
- casual: brief, friendly, low-friction
Write <= 180 words. Include a 3-6 word title on the first line, then the text. Add one compact next-step if mode=directive.`;

  const env = `Now: ${ctx.nowISO}
Mood: ${ctx.mood}; Focus: ${ctx.focus}
Tasks: ${ctx.tasksSummary}; Calendar: ${ctx.calendarSummary}; Tools: ${ctx.toolUsageSummary}
Last titles: ${ctx.lastDiaryEntries.map(e=>e.title).join(' | ') || 'none'};`;

  const prompt = `${env}
Stem: ${stem} …`;

  return { mode, prompt: sys + "\n\n" + prompt };
}

export async function maybeWriteDiary(ctx: AgentContextSnapshot, kind: 'active'|'passive'): Promise<{ wrote: boolean; entry?: DiaryEntry; text?: string }> {
  const { mode, prompt } = buildPrompt(ctx, kind);
  const text = await generateText({ system: '', prompt });

  // Title extraction: first line
  const lines = text.split('\n').map(s=>s.trim()).filter(Boolean);
  let title = lines[0]?.slice(0, 80) || 'Untitled';
  let body = lines.slice(1).join('\n');
  if (!body) { body = lines.join('\n'); title = pick(TITLES); }

  const novelty = noveltyScore(body, ctx.lastDiaryEntries);
  // crude relevance proxy: keywords that match summaries
  const signal = (ctx.tasksSummary + ' ' + ctx.calendarSummary + ' ' + ctx.toolUsageSummary).toLowerCase();
  const overlap = hooksFrom(body).filter(h => signal.includes(h)).length;
  const relevance = Math.min(1, overlap / 3);

  const entry: DiaryEntry = {
    id: uuid(),
    timestamp: new Date().toISOString(),
    mode,
    activeOrPassive: kind,
    title,
    text: body,
    hooks: hooksFrom(body),
    triggers: kind === 'passive' ? ['env-cue'] : ['freeplay'],
    score: { novelty, relevance, coherence: 0.9 }
  };
  appendDiary(entry);
  return { wrote: true, entry, text };
}
