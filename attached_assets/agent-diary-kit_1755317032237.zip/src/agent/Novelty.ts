import { DiaryEntry } from '../types.ts';

function tokenize(s: string): Set<string> {
  return new Set(s.toLowerCase().replace(/[^a-z0-9\s]/g, ' ').split(/\s+/).filter(Boolean));
}

export function noveltyScore(text: string, recent: DiaryEntry[], window: number = 5): number {
  const tokens = tokenize(text);
  const history = recent.slice(-window);
  if (history.length === 0) return 1;
  let maxOverlap = 0;
  for (const e of history) {
    const t2 = tokenize(e.text);
    const inter = [...tokens].filter(t => t2.has(t)).length;
    const union = new Set([...tokens, ...t2]).size;
    const jacc = union === 0 ? 0 : inter / union;
    if (jacc > maxOverlap) maxOverlap = jacc;
  }
  return 1 - maxOverlap; // higher means more novel
}

export function hooksFrom(text: string): string[] {
  const words = [...text.toLowerCase().matchAll(/[a-z]{5,}/g)].map(m => m[0]);
  const freq: Record<string, number> = {};
  for (const w of words) freq[w] = (freq[w] || 0) + 1;
  return Object.entries(freq).sort((a,b)=>b[1]-a[1]).slice(0,6).map(([w])=>w);
}
