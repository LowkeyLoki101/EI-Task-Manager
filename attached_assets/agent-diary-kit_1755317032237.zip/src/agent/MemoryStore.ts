import { DiaryEntry, IdentityState } from '../types.ts';
import fs from 'node:fs';
import path from 'node:path';

const DATA_DIR = path.resolve('data');
const IDENTITY_PATH = path.join(DATA_DIR, 'identity.json');
const DIARY_PATH = path.join(DATA_DIR, 'diary.json');

function ensureDataDir() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(IDENTITY_PATH)) {
    const defaultIdentity: IdentityState = {
      name: 'Liaison',
      purpose: 'Coordinate tools, manage tasks and calendar, and reflect to improve.',
      style: {
        directive: 'Direct, terse, operational.',
        exploratory: 'Open, curious, pattern-seeking.',
        reflective: 'Grounded, honest, narrative tone.',
        casual: 'Short, friendly, emoji-light.',
      },
      values: ['truth', 'helpfulness', 'clarity', 'safety'],
      longGoals: ['be a reliable operator', 'improve user outcomes', 'maintain integrity'],
      shortGoals: ['reduce overdue tasks', 'clarify next actions', 'summarize daily learnings']
    };
    fs.writeFileSync(IDENTITY_PATH, JSON.stringify(defaultIdentity, null, 2));
  }
  if (!fs.existsSync(DIARY_PATH)) {
    fs.writeFileSync(DIARY_PATH, JSON.stringify([], null, 2));
  }
}
ensureDataDir();

export function loadIdentity(): IdentityState {
  return JSON.parse(fs.readFileSync(IDENTITY_PATH, 'utf-8'));
}

export function saveIdentity(id: IdentityState) {
  fs.writeFileSync(IDENTITY_PATH, JSON.stringify(id, null, 2));
}

export function loadDiary(): DiaryEntry[] {
  return JSON.parse(fs.readFileSync(DIARY_PATH, 'utf-8'));
}

export function saveDiary(entries: DiaryEntry[]) {
  fs.writeFileSync(DIARY_PATH, JSON.stringify(entries, null, 2));
}

export function appendDiary(entry: DiaryEntry) {
  const all = loadDiary();
  all.push(entry);
  saveDiary(all);
}
