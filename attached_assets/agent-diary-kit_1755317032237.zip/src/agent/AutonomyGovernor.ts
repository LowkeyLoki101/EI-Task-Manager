import { AutonomyMode, DiaryEntry } from '../types.ts';
import { loadDiary } from './MemoryStore.ts';

export interface GateConfig {
  minIntervalSeconds: number;
  maxPerHour: number;
  noveltyThreshold: number;   // 0..1
  relevanceThreshold: number; // 0..1
}

export function shouldWriteDiary(
  mode: AutonomyMode,
  now: Date,
  relevance: number,
  novelty: number,
  cfg: GateConfig
): { allow: boolean; reason: string } {
  if (mode === 'OFF') return { allow: false, reason: 'Autonomy OFF' };

  const all = loadDiary();
  // Rate limit: min interval
  const last = all[all.length - 1];
  if (last) {
    const lastTime = new Date(last.timestamp).getTime();
    const deltaSec = (now.getTime() - lastTime) / 1000;
    if (deltaSec < cfg.minIntervalSeconds) {
      return { allow: false, reason: `Min interval gate (${cfg.minIntervalSeconds}s)` };
    }
  }
  // Rate limit: max per hour
  const oneHourAgo = now.getTime() - 3600_000;
  const recentCount = all.filter(e => new Date(e.timestamp).getTime() >= oneHourAgo).length;
  if (recentCount >= cfg.maxPerHour) {
    return { allow: false, reason: 'Max per hour reached' };
  }

  // Relevance/novelty
  if (relevance < cfg.relevanceThreshold) {
    return { allow: false, reason: `Relevance ${relevance.toFixed(2)} below threshold` };
  }
  if (novelty < cfg.noveltyThreshold) {
    return { allow: false, reason: `Novelty ${novelty.toFixed(2)} below threshold` };
  }
  return { allow: true, reason: 'All gates passed' };
}
