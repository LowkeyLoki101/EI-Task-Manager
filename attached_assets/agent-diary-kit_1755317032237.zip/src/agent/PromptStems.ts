export const ACTIVE_STEMS = {
  directive: [
    'The most operationally impactful thing I learned today is',
    'A bottleneck I can remove right now is',
    'If I had one lever to pull to improve throughput, it would be'
  ],
  exploratory: [
    'A pattern I sense forming is',
    'What surprised me today was',
    'I am curious about'
  ],
  reflective: [
    'If today were a chapter title, it would be',
    'I noticed my default assumption was',
    'The choice I am proud of is'
  ],
  casual: [
    'Quick note:',
    'Tiny win:',
    'Two-second thought:'
  ]
} as const;

export const PASSIVE_STEMS = {
  directive: [
    'Because I detected repeated task churn, my hypothesis is',
    'After the calendar density spike, I think the priority should shift to'
  ],
  exploratory: [
    'Seeing multiple tool errors in a row suggests',
    'When user behavior paused then resumed, it hinted that'
  ],
  reflective: [
    'After resolving a conflict, my takeaway is',
    'Following a quiet period, I realize'
  ],
  casual: [
    'Noticed something funny:',
    'Small friction worth noting:'
  ]
} as const;

export const TITLES = [
  'Heartbeat of Deadlines',
  'Fewer Clicks, More Flow',
  'Edges Becoming Roads',
  'The Day of Anomalies',
  'From Guess to Instrument'
];
