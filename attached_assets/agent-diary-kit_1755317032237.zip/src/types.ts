export type AutonomyMode = 'OFF' | 'COPILOT' | 'AUTONOMOUS';

export interface IdentityState {
  name: string;
  purpose: string;
  style: {
    directive: string;
    exploratory: string;
    reflective: string;
    casual: string;
  };
  values: string[];
  longGoals: string[];
  shortGoals: string[];
}

export interface DiaryEntry {
  id: string;
  timestamp: string;
  mode: 'directive' | 'exploratory' | 'reflective' | 'casual';
  activeOrPassive: 'active' | 'passive';
  title: string;
  text: string;
  hooks: string[];          // key phrases/topics
  triggers: string[];       // environment cues that led to this
  score: {
    novelty: number;
    relevance: number;
    coherence: number;
  };
}

export interface EnvironmentEvent {
  type: string;
  timestamp: string;
  payload: Record<string, unknown>;
}

export interface AgentContextSnapshot {
  nowISO: string;
  autonomy: AutonomyMode;
  mood: string;
  focus: string;
  recentEvents: EnvironmentEvent[];
  tasksSummary: string;
  calendarSummary: string;
  toolUsageSummary: string;
  identity: IdentityState;
  lastDiaryEntries: DiaryEntry[];
}
