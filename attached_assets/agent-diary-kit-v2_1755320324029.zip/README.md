# Agent Diary Kit — v2
This is the Colby-style knowledge builder scaffold (COLBY lens + KB + self-questions).